interface SectionHeadingProps {
  children: React.ReactNode
  className?: string
  /** Two-digit index, e.g. "01" - renders beside the label. */
  number?: string
}

/**
 * Divider-style section header: a small "01 -- Label" tag layered over an
 * oversized, cropped watermark of the same label. No container background -
 * the label and watermark sit directly on the page.
 */
export default function SectionHeading({
  children,
  className = '',
  number,
}: SectionHeadingProps) {
  return (
    <div className={`relative flex h-24 items-center overflow-hidden sm:h-32 md:h-36 ${className}`}>
      {/* Oversized watermark of the section name. */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute left-5 top-1/2 -translate-y-1/2 select-none whitespace-nowrap font-black uppercase leading-none tracking-tight text-slate-900/[0.06] sm:left-7 dark:text-white/[0.05]"
        style={{ fontSize: 'clamp(5rem, 15vw, 12rem)' }}
      >
        {children}
      </span>

      {/* Foreground label. */}
      <div className="relative z-10 flex items-center gap-3 pl-5 sm:pl-7">
        {number && (
          <span className="font-mono text-xs font-semibold text-emerald-600 dark:text-emerald-400">
            {number}
          </span>
        )}
        <span className="h-px w-8 bg-slate-400/60 sm:w-10 dark:bg-slate-600/70" />
        <h2 className="font-mono text-xs font-semibold uppercase tracking-[0.3em] text-slate-700 dark:text-slate-300">
          {children}
        </h2>
      </div>
    </div>
  )
}
