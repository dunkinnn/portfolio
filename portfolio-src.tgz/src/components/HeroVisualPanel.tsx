import { Code2, Palette } from 'lucide-react'

interface CodeToken {
  text: string
  className: string
}

interface CodeLine {
  indent?: number
  tokens: CodeToken[]
}

// Hand-picked editor-theme colors (not the site's monochrome tokens) so
// the code card reads as an actual syntax-highlighted snippet.
const CODE_LINES: CodeLine[] = [
  {
    tokens: [
      { text: 'const ', className: 'text-[#c792ea]' },
      { text: 'stack ', className: 'text-slate-200' },
      { text: '= ', className: 'text-slate-500' },
      { text: '[', className: 'text-slate-500' },
      { text: "'React'", className: 'text-[#c3e88d]' },
      { text: ', ', className: 'text-slate-500' },
      { text: "'Flutter'", className: 'text-[#c3e88d]' },
      { text: '];', className: 'text-slate-500' },
    ],
  },
  { tokens: [] },
  {
    tokens: [
      { text: 'export default function ', className: 'text-[#c792ea]' },
      { text: 'Angelou', className: 'text-[#82aaff]' },
      { text: '() {', className: 'text-slate-500' },
    ],
  },
  {
    indent: 1,
    tokens: [
      { text: 'return ', className: 'text-[#c792ea]' },
      { text: '<FullStackDev', className: 'text-[#89ddff]' },
    ],
  },
  {
    indent: 2,
    tokens: [
      { text: 'design', className: 'text-[#f78c6c]' },
      { text: '="UI/UX" ', className: 'text-[#c3e88d]' },
      { text: 'code', className: 'text-[#f78c6c]' },
      { text: '="clean" ', className: 'text-[#c3e88d]' },
      { text: '/>;', className: 'text-[#89ddff]' },
    ],
  },
  { tokens: [{ text: '}', className: 'text-slate-500' }] },
]

/**
 * The hero's right-column visual: a mock design-tool card anchors the
 * composition, with three satellites pinned one per corner so the piece
 * reads as a deliberate layout, not scattered decoration:
 *   top-left     -> mobile app card (reads "web + mobile", tucked behind
 *                    the design card so only its corner peeks out)
 *   top-right    -> "available for work" badge
 *   bottom-right -> code editor card (largest satellite, so it anchors
 *                    visual weight opposite the mobile card)
 *   bottom-left  -> stacked skill pills
 * A cursor hovering the design card's own CTA button (rather than a
 * separate floating tag) adds a "mid-session" detail without adding a
 * fifth floating piece. Everything is hand-built with Tailwind (no
 * screenshots) so it stays crisp at any size and follows the site's theme.
 * Purely decorative - aria-hidden, pointer-events-none since satellites
 * spill past the column edge. Float timing comes from the animate-float*
 * utilities in index.css (each corner its own duration/delay so satellites
 * drift out of sync), which already no-op under prefers-reduced-motion.
 */
export default function HeroVisualPanel() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none relative w-full max-w-sm"
    >
      {/* Ambient glow behind the cluster, plus a second smaller one tucked
          under the code card so the panel reads as layered, not flat. */}
      <div className="absolute -inset-8 -z-10 rounded-full bg-slate-400/10 blur-3xl dark:bg-slate-100/5" />
      <div className="absolute -bottom-4 -right-4 -z-10 h-32 w-32 rounded-full bg-slate-900/10 blur-3xl dark:bg-white/10" />

      {/* ============ TOP-LEFT: MOBILE APP CARD ============
          Rendered first (and behind, via -z-10) so it reads as tucked
          under the design card's corner rather than floating loose. */}
      <div className="animate-float-slow absolute -left-9 -top-9 -z-10 w-20 -rotate-6 rounded-[1.2rem] border border-slate-200/80 bg-white/90 p-1.5 shadow-xl ring-1 ring-black/5 backdrop-blur-md dark:border-white/10 dark:bg-slate-900/80 dark:ring-white/10">
        <div className="mx-auto mb-1.5 h-1.5 w-7 rounded-full bg-slate-200 dark:bg-slate-700" />
        <div className="mb-1.5 h-8 w-full rounded-lg bg-gradient-to-br from-slate-300 to-slate-100 dark:from-slate-700 dark:to-slate-800" />
        <div className="mb-1 h-1.5 w-4/5 rounded-full bg-slate-800 dark:bg-slate-100" />
        <div className="mb-2 h-1 w-3/5 rounded-full bg-slate-300 dark:bg-slate-600" />
        <div className="flex items-center justify-between px-0.5">
          <span className="h-1.5 w-1.5 rounded-full bg-slate-900 dark:bg-white" />
          <span className="h-1.5 w-1.5 rounded-full bg-slate-200 dark:bg-slate-700" />
          <span className="h-1.5 w-1.5 rounded-full bg-slate-200 dark:bg-slate-700" />
        </div>
      </div>

      {/* ============ DESIGN CARD (anchor) ============ */}
      <div className="animate-float relative overflow-hidden rounded-3xl border border-slate-200/80 bg-white/80 p-6 shadow-2xl ring-1 ring-black/5 backdrop-blur-md dark:border-white/10 dark:bg-slate-900/70 dark:ring-white/10">
        {/* top-edge sheen */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/60 to-transparent dark:via-white/20" />

        {/* window chrome */}
        <div className="mb-4 flex items-center gap-2.5">
          <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
          <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
          <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
          <span className="ml-1 h-5 flex-1 rounded-full bg-slate-100 dark:bg-slate-800" />
        </div>

        {/* fake nav row - CTA button carries a hovering cursor, standing
            in for a live design-tool session without a separate floater */}
        <div className="mb-5 flex items-center justify-between">
          <span className="h-2 w-14 rounded-full bg-slate-300 dark:bg-slate-700" />
          <div className="flex items-center gap-2">
            <span className="h-2 w-7 rounded-full bg-slate-200 dark:bg-slate-800" />
            <span className="h-2 w-7 rounded-full bg-slate-200 dark:bg-slate-800" />
            <span className="relative h-5 w-14 rounded-full bg-slate-900 dark:bg-white">
              <svg
                viewBox="0 0 16 16"
                className="absolute -bottom-2 -right-2 h-4 w-4 fill-sky-600 stroke-white drop-shadow dark:fill-sky-400 dark:stroke-slate-950"
                strokeWidth="1"
              >
                <path d="M1 1l5.6 13.2 2.1-5.3 5.3-2.1z" />
              </svg>
              <span className="absolute -bottom-4 left-6 whitespace-nowrap rounded-full rounded-tl-sm bg-sky-600 px-1.5 py-0.5 font-mono text-[8px] font-semibold text-white shadow dark:bg-sky-400 dark:text-slate-950">
                Angelou
              </span>
            </span>
          </div>
        </div>

        {/* fake headline */}
        <div className="mb-2 h-4 w-4/5 rounded-full bg-slate-800 dark:bg-slate-100" />
        <div className="mb-4 h-4 w-3/5 rounded-full bg-slate-300 dark:bg-slate-600" />

        {/* fake paragraph */}
        <div className="mb-1.5 h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-800" />
        <div className="mb-1.5 h-1.5 w-5/6 rounded-full bg-slate-200 dark:bg-slate-800" />
        <div className="mb-5 h-1.5 w-2/3 rounded-full bg-slate-200 dark:bg-slate-800" />

        {/* token swatches */}
        <div className="flex items-center gap-2">
          <span className="h-6 w-6 rounded-lg bg-slate-900 dark:bg-white" />
          <span className="h-6 w-6 rounded-lg bg-[#F24E1E]" />
          <span className="h-6 w-6 rounded-lg bg-slate-400 dark:bg-slate-500" />
          <span className="h-6 w-6 rounded-lg bg-slate-200 dark:bg-slate-700" />
        </div>
      </div>

      {/* ============ TOP-RIGHT: AVAILABILITY BADGE ============ */}
      <div className="animate-float-fast absolute -right-4 -top-4 z-20 flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/90 px-2.5 py-1.5 shadow-lg ring-1 ring-black/5 backdrop-blur-md dark:border-white/10 dark:bg-slate-900/90 dark:ring-white/10">
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-75" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
        </span>
        <span className="whitespace-nowrap font-mono text-[8px] font-semibold uppercase tracking-widest text-slate-700 dark:text-slate-200">
          Available for Work
        </span>
      </div>

      {/* ============ BOTTOM-LEFT: SKILL PILLS ============
          Stacked in one flex column so both pills share a single anchor
          point and a consistent gap, instead of two independently-offset
          floaters that can drift into each other. */}
      <div className="absolute -bottom-6 -left-7 z-20 flex flex-col items-start gap-2">
        <div className="animate-float-delayed flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/90 py-1.5 pl-1.5 pr-3 shadow-lg ring-1 ring-black/5 backdrop-blur-md dark:border-white/10 dark:bg-slate-900/90 dark:ring-white/10">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-slate-900 dark:bg-white">
            <Palette className="h-3 w-3 text-white dark:text-slate-950" strokeWidth={2} />
          </span>
          <span className="whitespace-nowrap font-mono text-[9px] font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-200">
            Design Systems
          </span>
        </div>

        <div className="animate-float-slow flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/90 py-1.5 pl-1.5 pr-3 shadow-lg ring-1 ring-black/5 backdrop-blur-md dark:border-white/10 dark:bg-slate-900/90 dark:ring-white/10">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-slate-900 dark:bg-white">
            <Code2 className="h-3 w-3 text-white dark:text-slate-950" strokeWidth={2} />
          </span>
          <span className="whitespace-nowrap font-mono text-[9px] font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-200">
            React + Flutter
          </span>
        </div>
      </div>

      {/* ============ BOTTOM-RIGHT: CODE CARD ============ */}
      <div className="animate-float-delayed absolute -bottom-8 -right-6 z-10 w-56 -rotate-3 rounded-2xl border border-white/10 bg-slate-900 p-4 font-mono text-[10.5px] leading-relaxed shadow-2xl ring-1 ring-white/5">
        {/* top-edge sheen */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px rounded-t-2xl bg-gradient-to-r from-transparent via-white/20 to-transparent" />

        <div className="relative mb-3 flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="h-2 w-2 rounded-full bg-[#ff5f56]" />
            <span className="h-2 w-2 rounded-full bg-[#ffbd2e]" />
            <span className="h-2 w-2 rounded-full bg-[#27c93f]" />
          </div>
          <span className="text-[9px] uppercase tracking-widest text-slate-400">
            Full-Stack Developer
          </span>
        </div>

        {CODE_LINES.map((line, i) => (
          <div
            key={i}
            className="whitespace-pre"
            style={{ paddingLeft: `${(line.indent ?? 0) * 0.9}rem` }}
          >
            {line.tokens.length === 0
              ? ' '
              : line.tokens.map((token, j) => (
                  <span key={j} className={token.className}>
                    {token.text}
                  </span>
                ))}
          </div>
        ))}
      </div>
    </div>
  )
}
